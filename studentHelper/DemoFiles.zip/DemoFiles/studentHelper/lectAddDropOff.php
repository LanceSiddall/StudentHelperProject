<?PHP

require 'Database/configure.php';

$conn=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, MYSQL_DB);

$buildName = $_POST['dropOfname'];
$roomName = $_POST['roomName'];
$dateAndTime = $_POST['dateAndTime'];


$newRoom = $conn->query("INSERT INTO dropOff (dropOfname, roomName, dateAndTime) VALUES ('{$buildName}','{$roomName}','{$dateTime}')");

header('location: courseworkDropoff.php');

?>
