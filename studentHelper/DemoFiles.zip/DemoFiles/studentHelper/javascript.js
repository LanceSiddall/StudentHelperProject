function SuccSign() {
alert("Sign up successfull, you may now login.");
}

function newGroup() {
  alert("Study Group Added!");
}

function removeStudent() {
  alert("Student removed");
}

function groupJoined() {
  alert("Successfully joined group");

}

function wrongUserPass() {
  alert("Wrong username or password");
}

function roomAdded() {
  alert("Room Added");
}

function DropOffAdded() {
  alert("Drop Off Added");
}
